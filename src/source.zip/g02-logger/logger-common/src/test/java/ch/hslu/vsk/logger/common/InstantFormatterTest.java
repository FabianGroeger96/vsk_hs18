package ch.hslu.vsk.logger.common;

import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

import static org.junit.Assert.*;

public class InstantFormatterTest {

    private String testStringTime;
    private Instant testInstant;

    @Before
    public void setUp() throws Exception {
        this.testStringTime = "2018-11-05T22:54:56.801Z";
        this.testInstant = Instant.parse(testStringTime);
    }

    @Test
    public void getInstant() {
        assertEquals(this.testInstant, InstantFormatter.getInstant(testStringTime));
    }
    
    @Test
    public void getString() {
        assertEquals(this.testStringTime, InstantFormatter.getString(testInstant));
    }
}