package ch.hslu.vsk.logger.server;

import ch.hslu.vsk.logger.common.InstantFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.logger.common.MessageHandler.AbstractMessage;
import ch.hslu.vsk.logger.common.MessageHandler.LogDataMessage;
import java.time.Instant;


public class LogDataMessageServer extends LogDataMessage {

    private LogServer logServer;

    public LogDataMessageServer(LogServer server){
        this.logServer = server;
    }

    @Override
    public boolean operate() {
        boolean success = false;
        String message = (String) getArg(4);
        int logLevel = (int) getArg(3);
        Instant time = InstantFormatter.getInstant((String) getArg(0));
        int logID = (int) getArg(2);
        String loggerID = (String) getArg(1);
        LogMessage logMessage = new LogMessage(message, logLevel, time, logID, loggerID);
        logServer.storeNewLogMessage(logMessage);
        success = true;
        return success;
    }

    @Override
    public AbstractMessage newCopy() {
        return new LogDataMessageServer(this.logServer);
    }

}
