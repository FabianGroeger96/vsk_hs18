## Context

[Detaillierte Beschreibung vom Issue]

## Definition of Done

* [ ]  Code-Review von mindestens einem Teammitglied
* [ ]  Bestehende Tests erfolgreich durchgelaufen
* [ ]  Build nach Jenkins Ablauf kann erstellt werden
* [ ]  Issue für Dokumentation erfasst
* [ ]  Änderungen in GitLab erfasst
