package ch.hslu.vsk.logger.common;
import java.io.Serializable;
import java.time.Instant;

/**
 * enthaelt die geloggte Nachricht inklusive Attribute
 */

public class LogMessage implements Serializable {

    /**
     * enthaelt die geloggte Nachricht.
     */
    private String logMessage;

    /**
     * enthaelt den LogLevel (Als Enumeration innerhalb der Projektanforderung vorgegeben).
     */
    private int logLevel;

    /**
     * enthaelt die ID der geloggten Nachricht.
     */
    private int logID;

    /**
     * enthaelt die Zeit, wann der Log erstellt wurde.
     */
    private Instant logTime;

    /**
     * enthaelt die ID des Loggers.
     */
    private String loggerID;

    /**
     * Konstruktor welcher alle Properties der Klasse definiert. Uebergabeparameter in gleichen Typen wie die Klassen Properties.
     * @param logMessage Textinhalt der LogMessage.
     * @param logLevel LogLevel der LogMessage. Als Enumeration innerhalb der Projektanforderung vorgegeben.
     * @param logTime Zeitpunkt der LogMessage innerhalb des Logger. Als Instant fuer die Verwendung in PersistedString.
     * @param logID ID der LogMessage innerhalb des Loggers, welche die Message geloggt hat.
     * @param loggerID ID des Loggers welche die Message geloggt hat. Als String da von Logger Interface vorgegeben.
     */
    public LogMessage(String logMessage, int logLevel, Instant logTime, int logID, String loggerID){
        this.logMessage = logMessage;
        this.logLevel = logLevel;
        this.logTime = logTime;
        this.logID = logID;
        this.loggerID = loggerID;
    }

    /**
     * getter-Methode fuer die geloggte Nachricht.
     * @return die Nachricht selbst die geloggt wurde.
     */
    public String getMessage() {
        return this.logMessage;
    }

    /**
     * getter-Methode fuer die ID der Nachricht.
     * @return die ID des Logeintrags.
     */
    public int getLogID() {
        return this.logID;
    }

    /**
     * getter-Methode fuer Zeit, wann die Nachricht geloggt wurde.
     * @return die Zeit, wann der Log erstellt wurde.
     */
    public Instant getLogTime() {
        return this.logTime;
    }

    /**
     * getter-Methode fuer die ID des Loggers.
     * @return die ID des Logger.
     */
    public String getLoggerID() {
        return this.loggerID;
    }

    /**
     * getter-Methode fuer LogLevel der LogMessage (Als Enumeration innerhalb der Projektanforderung vorgegeben).
     * @return den Level mit dem die Nachricht geloggt wurde.
     */
    public int getLogLevel(){
        return this.logLevel;
    }


}
