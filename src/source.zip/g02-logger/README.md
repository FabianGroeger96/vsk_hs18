# Logger

Implementation des Loggers der Gruppe g02 im VSK-18FS, der Logger sollte vom Game of Life (GoL) verschiedene Zustände loggen.


## Mitglieder

* Richner Patrick
* Barmettler Reto
* Krasniqi Adhurim
* Fabian Gröger

### Buildstatus
* [![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/buildStatus/icon?job=g02-logger)](https://jenkins-vsk.el.eee.intern/jenkins/job/g02-logger/)

> Hinweis: Buildstatus nur innerhalb HSLU-Netz (oder per VPN) sichtbar!

