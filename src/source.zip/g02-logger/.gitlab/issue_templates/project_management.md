## Beschreibung

[Detaillierte Beschreibung vom Issue]

## Definition of Done

* [ ]  Wurde vom ganzen Team akzeptiert
* [ ]  Änderungen in GitLab erfasst
