package ch.hslu.vsk.logger.common.Adapter;

import ch.hslu.vsk.logger.common.LogMessage;

import java.util.List;

/**
 * Interface, dass die Schnittstelle der zu uebergebenden Loggs definiert.
 */
public interface LogPersistor {

    /**
     * Speichert die uebergebene LogMessage
     * @param log die uebergebene LogMessage zum sichern
     */
    public void save(LogMessage log);

    /**
     * Gibt eine Liste von PersistedLogs zurueck
     * @param count die Anzahl PersistedLogs, welche ausgelesen werden sollen
     * @return eine Liste von PersistedLogs
     */
    public List<PersistedLog> get(final int count);


}
