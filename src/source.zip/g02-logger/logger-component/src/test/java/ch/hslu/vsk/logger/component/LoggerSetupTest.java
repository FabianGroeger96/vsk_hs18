package ch.hslu.vsk.logger.component;

import ch.hslu.vsk.logger.api.LogLevel;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.ConnectException;

import static org.junit.Assert.*;

public class LoggerSetupTest {

    private Logger testLogger;
    private String testLoggerID;
    private LogLevel testMinimumLoglevel;
    private String testServerHostName;
    private int testServerPort;

    @Before
    public void setUp() throws ConnectException {
        this.testLoggerID = "testLogger";
        this.testMinimumLoglevel = LogLevel.TRACE;
        this.testServerHostName = "testServer";
        this.testServerPort = 20;
        this.testLogger = new Logger(testLoggerID, testMinimumLoglevel, testServerHostName, testServerPort);
    }

    @Test(expected = ConnectException.class)
    public void getLogger() throws ConnectException {
        LoggerSetup loggerSetup = new LoggerSetup();
        Logger logger = loggerSetup.getLogger(testLoggerID, testMinimumLoglevel, testServerHostName, testServerPort);
        assertEquals(testLogger.getID(), logger.getID());
    }
}