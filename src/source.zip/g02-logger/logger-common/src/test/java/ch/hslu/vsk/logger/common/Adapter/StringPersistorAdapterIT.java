package ch.hslu.vsk.logger.common.Adapter;

import ch.hslu.vsk.logger.common.Formatter.DefaultFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.stringpersistor.impl.StringPersistorFile;
import org.junit.Before;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class StringPersistorAdapterIT {

    private StringPersistorFile stringPersistorFile;
    private DefaultFormatter defaultFormatter;
    private LogPersistor logPersistor;
    private File tmpFile;

    String logMessage;
    int logLevel;
    Instant logTime;
    int logID;
    String loggerID;

    @Before
    public void setUp() throws Exception {
        this.stringPersistorFile = new StringPersistorFile();
        this.defaultFormatter = new DefaultFormatter();

        this.tmpFile = File.createTempFile("StringPersistorAdapterTest", ".txt");
        this.stringPersistorFile.setFile(this.tmpFile);

        this.logPersistor = StringPersistorAdapter.create(this.defaultFormatter, this.stringPersistorFile);

        this.logMessage = "Test Message";
        this.logLevel = 10;
        this.logTime = Instant.now();
        this.logID = 1;
        this.loggerID = "test-logger";
    }

    @Test
    public void testAdapter() throws Exception {
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.logTime, this.logID, this.loggerID);

        this.logPersistor.save(logMessage);

        final BufferedReader reader = new BufferedReader(new FileReader(this.tmpFile));
        List<String> logFileContent = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.isEmpty()){
                break;
            }
            logFileContent.add(line);
        }

        LogMessage parsedMessage = this.defaultFormatter.parse(logFileContent.get(1));
        assertEquals(this.logMessage, parsedMessage.getMessage());
        assertEquals(this.logLevel, parsedMessage.getLogLevel());
        assertEquals(this.logTime, parsedMessage.getLogTime());
        assertEquals(this.logID, parsedMessage.getLogID());
        assertEquals(this.loggerID, parsedMessage.getLoggerID());

        reader.close();
    }
}