package ch.hslu.vsk.logger.server;

import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.stringpersistor.impl.StringPersistorFile;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.rmi.AlreadyBoundException;
import java.time.Instant;
import java.util.Date;
import static org.junit.Assert.*;

public class LogServerIT {

    @Test
    public void empty(){
        assertTrue(true);
    }

    String logMessage;
    int logLevel;
    Instant date;
    int logID;
    String loggerID;

    LogServer logServer;
    int port;

    String persistorFile;


    @Before
    public void setup(){
        this.logMessage = "Test Message";
        this.logLevel = 10;
        this.date = Instant.now();
        this.logID = 1;
        this.loggerID = "test-logger";

        this.port = 1234;

        this.persistorFile = "default.log";
    }

    @Test
    public void testStoreMessageToServer() throws IOException, AlreadyBoundException {
        LogMessage message = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        StringPersistorFile stringPersistorFile = new StringPersistorFile();
        File file = new File(this.persistorFile);
        file.createNewFile();
        stringPersistorFile.setFile(file);
        logServer = new LogServer(this.port, stringPersistorFile);
        boolean result = logServer.storeNewLogMessage(message);
        assertTrue(result);
    }
}






