package ch.hslu.vsk.logger.component;

import ch.hslu.vsk.logger.api.LogLevel;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

import java.lang.reflect.Field;
import java.net.ConnectException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class LoggerTest {

    String loggerID;
    LogLevel logLevel;
    String logHost;
    int logPort;
    int timeOut;

    String logMessage;

    @Before
    public void setup() {
        this.loggerID = "1234";
        this.logLevel = LogLevel.INFO;
        this.logHost = "192.168.1.1";
        this.logPort = 88;
        this.timeOut = 10;

        this.logMessage = "This is a test message";
    }

    @Test(expected = ConnectException.class)
    public void getID() throws ConnectException {
        LoggerSetup loggerSetup = new LoggerSetup();
        Logger logger = loggerSetup.getLogger(this.loggerID, this.logLevel, this.logHost, this.logPort);

        assertEquals(this.loggerID, logger.getID());
    }

    @Test(expected = ConnectException.class)
    public void setMinimumLogLevel() throws NoSuchFieldException, IllegalAccessException, ConnectException {
        LoggerSetup loggerSetup = new LoggerSetup();
        Logger logger = loggerSetup.getLogger(this.loggerID, this.logLevel, this.logHost, this.logPort);

        logger.setMinimumLogLevel(LogLevel.DEBUG);

        final Field field = logger.getClass().getDeclaredField("minimumLogLevel");
        field.setAccessible(true);

        assertEquals(LogLevel.DEBUG, field.get(logger));
    }

    @Test
    public void log() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);

        ArgumentCaptor<LogLevel> logLevelArgumentCaptor = ArgumentCaptor.forClass(LogLevel.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);

        doNothing().when(loggerMock).log(logLevelArgumentCaptor.capture(), logMessageArgumentCaptor.capture());

        loggerMock.log(this.logLevel, this.logMessage);

        assertEquals(this.logLevel, logLevelArgumentCaptor.getValue());
        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void generateLogMessageFromLog() {

    }

    @Test
    public void trace() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).trace(logMessageArgumentCaptor.capture());

        loggerMock.trace(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void debug() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).debug(logMessageArgumentCaptor.capture());

        loggerMock.debug(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void info() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).info(logMessageArgumentCaptor.capture());

        loggerMock.info(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void warning() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).warning(logMessageArgumentCaptor.capture());

        loggerMock.warning(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void error() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).error(logMessageArgumentCaptor.capture());

        loggerMock.error(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void critical() {
        ch.hslu.vsk.logger.api.Logger loggerMock = Mockito.mock(ch.hslu.vsk.logger.api.Logger.class);
        ArgumentCaptor<String> logMessageArgumentCaptor = ArgumentCaptor.forClass(String.class);
        doNothing().when(loggerMock).critical(logMessageArgumentCaptor.capture());

        loggerMock.critical(this.logMessage);

        assertEquals(this.logMessage, logMessageArgumentCaptor.getValue());
    }

    @Test
    public void connectToServer() {
    }

    @Test
    public void hasConnectionToServer() {
    }

    @Test
    public void writeLogMessageToServer() {
    }

    @Test
    public void writeLogMessageToCache() {
    }

    @Test
    public void writeCacheToServer() {
    }

    @Test
    public void clearCache() {
    }

}