package hslu.vsk.team2;

import java.time.LocalDateTime;

/**
 * Übung: VSK "Game of Life"
 * Aufgabe: Logger
 *
 * @author Fabian Gröger
 * @version 27.09.2018
 */
public interface LogMessage {

    /**
     * Gets the origin of the message
     * @return the origin
     */
    Logger getOrigin();

    /**
     * Gets the log level of the message
     * @return the log level
     */
    LogLevel getLogLevel();

    /**
     * Gets the text of the message
     * @return the text
     */
    String getMessage();

    /**
     * Gets the LocalDateTime when the message was created
     * @return the created time of the message
     */
    LocalDateTime getCreatedAt();

    /**
     * Gets the LocalDateTime when the message was received at the server
     * @return the time when the message was received
     */
    LocalDateTime getReceivedAt();

}
