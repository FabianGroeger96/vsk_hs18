package ch.hslu.vsk.logger.server;

import ch.hslu.vsk.logger.common.Adapter.LogPersistor;
import ch.hslu.vsk.logger.common.Adapter.PersistedLog;
import ch.hslu.vsk.logger.common.Adapter.StringPersistorAdapter;
import ch.hslu.vsk.logger.common.ConfigurationFileReader.ConfigurationFileReader;
import ch.hslu.vsk.logger.common.Formatter.DefaultFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.logger.common.MessageHandler.MessageHandler;
import ch.hslu.vsk.logger.common.RMI.RMIListener;
import ch.hslu.vsk.logger.common.RMI.RMIServer;
import ch.hslu.vsk.stringpersistor.impl.StringPersistorFile;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LogServer implements Runnable, RMIServer {

    private final ExecutorService handlerPool;

    /**
     * Beeinhaltet die PersistedLogs welche gespeichert werden
     */
    private ArrayList<PersistedLog> logMessageStore;

    private LogPersistor logPersistor;

    private ConcurrentSkipListSet<RMIListener> listeners;

    private Remote registryServer;

    private ServerSocket listen;

    public LogServer(int port) throws IOException {
        this.logMessageStore = new ArrayList<>();
        this.listen = new ServerSocket(port);
        this.handlerPool = Executors.newCachedThreadPool();
        listeners = new ConcurrentSkipListSet<>();
    }

    public LogServer(int port, StringPersistorFile stringPersistor) throws IOException, AlreadyBoundException {
        this(port);
        this.logPersistor = StringPersistorAdapter.create(new DefaultFormatter(), stringPersistor);
        this.readStringPersistorFile();
    }

    private void registerRMIRegistry() throws AlreadyBoundException, RemoteException {
        final Registry reg = LocateRegistry.getRegistry(Registry.REGISTRY_PORT);
        this.registryServer = UnicastRemoteObject.exportObject(this, 0);
        reg.bind("logServer", this.registryServer);
    }

    /**
     * Fuegt einen dem Server einen RMI Listener hinzu
     * @param listener der RMI Listener um dem Server hinzuzufuegen
     */
    @Override
    public void addListener(RMIListener listener) {
        listeners.add(listener);
        for (PersistedLog persistedLog : logMessageStore){
            try {
                listener.push(persistedLog);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Loescht den uebergebenen RMI Listener vom Server
     * @param listener der RMI Listener um vom Server zu loeschen
     */
    @Override
    public void removeListener(RMIListener listener) {
        listeners.remove(listener);
    }

    public void update(PersistedLog message) {
        for (RMIListener listener: listeners) {
            try {
                listener.push(message);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    private static List<Object> readServerConfiguration(String fileName){
        Properties prop = ConfigurationFileReader.readConfigurationFile(fileName);
        int port = 1234;
        ArrayList<Object> args = new ArrayList<>();
        if (prop != null){
            if (prop.getProperty("PORT") != null){
                System.out.println("Found PORT Configuration in configuration file: " + fileName);
                port = Integer.parseInt(prop.getProperty("PORT"));
            }
        }
        args.add(port);
        return args;
    }

    public static void main(String args[]) throws AlreadyBoundException, RemoteException {

        System.out.println("Starting LogServer of Group-02!");
        System.out.println("-----------------------------------");
        String workingdir = System.getProperty(("user.dir"));
        String fileName = "server.config";
        String persistorFile = "default.log";

        if (args.length == 0){
            System.out.println("No Configuration File stated!");
            System.out.println("Searching for 'server.config' in " + workingdir);
        }
        else if (args.length ==  1){
            System.out.println("Configuration File stated!");
            fileName = ((String) args[0]);
            System.out.println("Using configuration File in path: " + fileName);
        }

        System.out.println("-----------------------------------");
        List<Object> configurationArgument = readServerConfiguration(fileName);
        int port = (Integer) configurationArgument.get(0);
        System.out.println("-----------------------------------");
        System.out.println("Starting RMI Server Thread");
        new Thread(new LogServerRMIRegistry(), "RMI LogServer").start();
        System.out.println("-----------------------------------");
        System.out.println(String.format("Creating StringPersistorFile with filepath: " + persistorFile));
        File file = new File(persistorFile);
        StringPersistorFile stringPersistorFile = new StringPersistorFile();
        stringPersistorFile.setFile(file);
        System.out.println("-----------------------------------");
        LogServer server = null;
        try {
            System.out.println("Creating LogServer with StringPersistorFile: " + file.getAbsolutePath());
            server = new LogServer(port, stringPersistorFile);
        } catch (IOException e) {
            System.out.println("Could not read File: " + file);
            System.out.println("Please make sure it exists and is in proper Log Format");
            System.exit(-1);
        }
        System.out.println("Starting Server on Port: " + port);
        server.registerRMIRegistry();
        server.run();
    }

    synchronized boolean storeNewLogMessage(LogMessage logMessage){
        this.addPersistedLogToStore(new PersistedLog(Instant.now(), logMessage));
        logPersistor.save(logMessage);
        return true;
    }

    private void addPersistedLogToStore(PersistedLog persistedLog){
        logMessageStore.add(persistedLog);
        this.update(persistedLog);
    }

    private void addAllPersistedLogToStore(List<PersistedLog> persistedLogs){
        for (PersistedLog persistedLog : persistedLogs){
            this.addPersistedLogToStore(persistedLog);
        }

    }

    private void readStringPersistorFile(){
        List<PersistedLog> add = this.logPersistor.get(Integer.MAX_VALUE);
        this.addAllPersistedLogToStore(add);
    }

    @Override
    public void run() {
        while (true) {
            try {
                final Socket client = this.listen.accept();
                final MessageHandler messageHandler =
                        new MessageHandler(client.getInputStream(), client.getOutputStream());
                messageHandler.addMessageType(new LogDataMessageServer(this));
                handlerPool.execute(messageHandler);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
