package ch.hslu.vsk.logger.common;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

public class InstantFormatter {
    public static Instant getInstant(String formattedString){
        return Instant.parse(formattedString);
    }
    public static String getString(Instant instantToFormat){
        return DateTimeFormatter.ISO_INSTANT.format(instantToFormat);
    }
}
