package hslu.vsk.team2;

/**
 * Übung: VSK "Game of Life"
 * Aufgabe: Logger
 *
 * @author Fabian Gröger
 * @version 27.09.2018
 */
public interface LoggerSetup {

    /**
     * Creates a new LoggerSetup
     * @return the created LoggerSetup
     */
    LoggerSetup create();

    /**
     * Connects a Logger with the configured parameters
     * @param logger the Logger to connect to the LoggerSetup
     */
    void connect(Logger logger);

    /**
     * Gets the log server address
     * @return the log server address
     */
    String getServerAdress();

    /**
     * Sets the log server address
     * @param address the log server address
     */
    void setServerAdress(String address);

    /**
     * Gets the port to connect to the log server
     * @return the port of the log server
     */
    int getPortNumber();

    /**
     * Sets the port to connect to the log server
     * @param portNumber the port of the log server
     */
    void setPortNumber(int portNumber);

    /**
     * Gets the minimum log level which will be reported to the server
     * @return the minimum log level
     */
    LogLevel getLogLevel();

    /**
     * Sets the minimum log level which will be reported to the server
     * @param logLevel the minimum log level
     */
    void setLogLevel(LogLevel logLevel);

    /**
     * Gets the maximum timeout in milliseconds for the connection to the log server
     * @return the maximum timeout
     */
    int getServerMaxTimeoutMilliseconds();

    /**
     * Sets the maximum timeout in milliseconds for the connection to the log server
     * @param timeoutMilliseconds the maximum timeout
     */
    void setServerMaxTimeoutMilliseconds(int timeoutMilliseconds);
}
