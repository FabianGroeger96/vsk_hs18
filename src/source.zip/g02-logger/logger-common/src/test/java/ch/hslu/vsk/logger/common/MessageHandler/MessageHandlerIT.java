package ch.hslu.vsk.logger.common.MessageHandler;

import org.junit.Test;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

import static org.junit.Assert.*;


public class MessageHandlerIT {

    private int testValue;

    private class TestMessage extends AbstractMessage {

        private static final String MESSAGE_TYPE = "TEST";

        private TestMessage(){
            super();
        }

        @Override
        public boolean readArgs(InputStream inputStream) {
            final DataInputStream dataInputStream = new DataInputStream(inputStream);
            try {
                addArg(dataInputStream.readInt());
                addArg(dataInputStream.readInt());
                String temp = dataInputStream.readUTF();
                while (temp.compareTo(this.getEndToken()) != 0) {
                    temp = dataInputStream.readUTF();
                }
            } catch (IOException e) {
                return false;
            }
            return true;
        }

        @Override
        public boolean writeArgs(OutputStream outputStream) {
            final DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            try{
                dataOutputStream.writeInt((Integer) this.getArgList().get(0));
                dataOutputStream.writeInt((Integer) this.getArgList().get(1));
                dataOutputStream.writeUTF(this.getEndToken());
            } catch (IOException e) {
                return false;
            }
            return true;
        }

        @Override
        public boolean operate() {
            testValue = (Integer) this.getArgList().get(0) + (Integer) this.getArgList().get(1);
            return true;
        }

        @Override
        public boolean handles(String messageType) {
            return messageType.compareTo(MESSAGE_TYPE) == 0;
        }

        @Override
        public AbstractMessage newCopy() {
            return (new TestMessage());
        }

        @Override
        protected void defineMessageType() {
            this.setMessageType(MESSAGE_TYPE);

        }

    }

//    @Test
//    public void testSendAndReadMessage() throws IOException{
//
//        Thread serverThread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    ServerSocket server = new ServerSocket(2222);
//                    while (true) {
//                        Socket clientStream = server.accept();
//                        MessageHandler handler = new MessageHandler(clientStream.getInputStream(), clientStream.getOutputStream());
//                        Thread handlerThread = new Thread(handler);
//                        handlerThread.start();
//                    }
//                } catch (IOException e){
//                    e.printStackTrace();
//                }
//            }
//        });
//        serverThread.start();
//
//        Socket client = new Socket("127.0.0.1", 2222);
//        MessageHandler handlerClient = new MessageHandler(client.getInputStream(), client.getOutputStream());
//        handlerClient.addMessageType(new TestMessage());
//        TestMessage message = new TestMessage();
//        message.addArg(4);
//        message.addArg(6);
//        handlerClient.sendMessage(message);
//        assertEquals(10, testValue);
//
//    }

    @Test
    public void testBuildMessageAndAddMessageType(){
        MessageHandler messageHandler = new MessageHandler();
        messageHandler.addMessageType(new TestMessage());
        AbstractMessage message = messageHandler.buildMessage("TEST");
        AbstractMessage notAllowedMessage = messageHandler.buildMessage("NOTALLOWED");
        boolean notAllowedMessageIsNull = false;
        if (notAllowedMessage == null) {
            notAllowedMessageIsNull = true;
        }

        assertEquals(message.getMessageType(), "TEST");
        assertTrue(notAllowedMessageIsNull);

    }

}