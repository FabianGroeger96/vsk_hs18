package ch.hslu.vsk.stringpersistor.impl;

import ch.hslu.vsk.stringpersistor.api.PersistedString;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

public class StringPersistorFileTest {

    private File testFile;
    private String testFileUrl;
    private StringPersistorFile stringPersistorFile;
    private String testPayload;
    private String testInstantString;
    private Instant testInstant;
    private PersistedString testPersistedString;
    private List<PersistedString> testList;

    @Before
    public void setUp() throws IOException {
        this.testFileUrl = "testFile.txt";
        this.testFile = new File(testFileUrl);
        this.stringPersistorFile = new StringPersistorFile();
        this.testList = new ArrayList<>();
        this.testInstant = Instant.parse("2018-11-05T22:52:56.801Z");
        this.testInstantString = "2018-11-05T22:52:56.801Z";
        this.testPayload = "2018-11-05T22:52:44.668Z/-/test-logger/-/1/-/20/-/Test Log Message";
        testList.add(new PersistedString(testInstant, testPayload));
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(testFile), StandardCharsets.UTF_8));
        writer.write(testInstantString);
        writer.newLine();
        writer.write(testPayload);
        writer.newLine();
        writer.close();
    }

    @After
    public void tearDown() throws IOException {

    }

    @Test
    public void testSetFile(){
        /* Arrange */
        /* Act */
        stringPersistorFile.setFile(testFile);
        /* Assert */
        assertEquals(testList, stringPersistorFile.get(1));
    }

    @Test
    public void testSave(){
        /* Arrange */
        testInstantString = "2018-11-05T22:54:56.801Z";
        testPayload = "2018-11-05T22:57:44.668Z/-/test-logger2/-/2/-/30/-/Test Log Message Save";
        testInstant = Instant.parse(testInstantString);
        testPersistedString = new PersistedString(testInstant, testPayload);
        testList.add(testPersistedString);
        stringPersistorFile.setFile(testFile);
        /* Act */
        stringPersistorFile.save(testInstant, testPayload);
        /* Assert */
        assertEquals(testList, stringPersistorFile.get(2));
    }
    
}