#!/bin/sh

echo "Executing HTTP Server..."
java -jar ../tools.jar -dir ../. -verbose -port 8080
