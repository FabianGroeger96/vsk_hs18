package ch.hslu.vsk.logger.common.RMI;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RMIServer extends Remote {
    void addListener(RMIListener listener) throws RemoteException;
    void removeListener(RMIListener listener) throws RemoteException;
}
