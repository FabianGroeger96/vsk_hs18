package ch.hslu.vsk.logger.common.Adapter;

import ch.hslu.vsk.logger.common.LogMessage;

import java.io.Serializable;
import java.time.Instant;

public class PersistedLog implements Serializable {

    private LogMessage message;
    private Instant savestamp;

    /**
     * Erstellt einen PersistedLog, mit den uebergebenen Parametern
     * @param savestamp eine Instant, wann die LogMessage gespeichert wurde
     * @param message die zugehoerige LogMessage
     */
    public PersistedLog(final Instant savestamp, final LogMessage message){
        this.message = message;
        this.savestamp = savestamp;
    }

    /**
     * Gibt die zugehoerige LogMessage des PersistedLogs zurueck
     * @return die LogMessage
     */
    public LogMessage getMessage() {
        return message;
    }

    /**
     * Gibt die zugehoerige Instant des PersistedLogs zurueck,
     * wann die LogMessage gespeichert wurde
     * @return die Instant
     */
    public Instant getSavestamp() {
        return savestamp;
    }
}
