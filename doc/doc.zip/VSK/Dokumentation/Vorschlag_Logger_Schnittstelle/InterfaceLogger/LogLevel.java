package hslu.vsk.team2;

/**
 * Übung: VSK "Game of Life"
 * Aufgabe: Logger
 *
 * @author Fabian Gröger
 * @version 27.09.2018
 */
public enum LogLevel {

    ALL, // Alle Meldungen werden ungefiltert ausgegeben
    TRACE, // ausführlicheres Debugging, Kommentare
    DEBUG, // allgemeines Debugging
    INFO, // allgemeine Informationen
    WARN, // Auftreten einer unerwarteten Situation
    ERROR, // Fehler
    FATAL, // Kritischer Fehler, Programmabbruch
    OFF // Logging ist deaktiviert
}
