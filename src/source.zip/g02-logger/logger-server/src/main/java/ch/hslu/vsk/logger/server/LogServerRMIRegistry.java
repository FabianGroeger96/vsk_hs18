package ch.hslu.vsk.logger.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class LogServerRMIRegistry implements Runnable {

	@Override
	public void run() {
		try {
			Registry registry = LocateRegistry.createRegistry(Registry.REGISTRY_PORT); // 1099
			synchronized (registry) {
				registry.wait();
			}
		} catch (RemoteException | InterruptedException e) {
			e.printStackTrace();
		}

	}

}
