package ch.hslu.vsk.logger.common.MessageHandler;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class MessageHandler implements Runnable {

    protected InputStream inputStream;
    protected OutputStream outputStream;
    private List<AbstractMessage> handledMessages;

    public MessageHandler(){
        handledMessages = new ArrayList<>();
    }

    public MessageHandler(final InputStream inputStream, final OutputStream outputStream){
        this();
        this.inputStream = inputStream;
        this.outputStream = outputStream;
    }

    public final void addMessageType(final AbstractMessage msgType){
        handledMessages.add(msgType);
    }

    public final AbstractMessage readMessage() throws IOException {
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        String messageType = dataInputStream.readUTF();
        AbstractMessage message = buildMessage(messageType);
        if(message != null && message.readArgs(inputStream)){
            return message;
        }
        return null;
    }

    public final void sendMessage(final AbstractMessage message) throws IOException {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
        dataOutputStream.writeUTF(message.getMessageType());
        message.writeArgs(outputStream);
    }

    @Override
    public void run() {
        boolean busy = true;
        while(busy) {
            AbstractMessage message = null;
            try {
                message = readMessage();
            } catch (UTFDataFormatException e){
               // e.printStackTrace();
            } catch (IOException e) {
                busy = false;
            }
            if (message != null) {
                message.operate();
            }
        }
        try {
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected final AbstractMessage buildMessage(final String msgType) {
        for(AbstractMessage msg : handledMessages) {
            if (msg.handles(msgType)) {
                return msg.newCopy();
            }
        }
        return null;
    }

}
