package ch.hslu.vsk.logger.common.ConfigurationFileReader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigurationFileReader {

    public static Properties readConfigurationFile(String fileName){
        Properties prop = new Properties();
        InputStream is = null;
        try {
            System.out.println("Try to read File " + fileName);
            is = new FileInputStream(fileName);
        } catch (FileNotFoundException ex) {
            System.out.println("Could not find Configuration File! Using Standard Values");
            is = null;
        }
        if (is != null){
            try {
                System.out.println("Try to load configuration from config file: " + fileName);
                prop.load(is);
            } catch (IOException | NullPointerException ex) {
                System.out.println("Config File could not be read! Using Standard Values");
            }
        }
        return prop;

    }


}
