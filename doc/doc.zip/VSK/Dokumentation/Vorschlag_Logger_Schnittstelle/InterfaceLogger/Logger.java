package hslu.vsk.team2;

/**
 * Übung: VSK "Game of Life"
 * Aufgabe: Logger
 *
 * @author Fabian Gröger
 * @version 27.09.2018
 */
public interface Logger {

    /**
     * Creates a new Logger
     * @param setup a LoggerSetup which contains all of the configurations for the Logger
     * @return the created Logger
     */
    Logger start(LoggerSetup setup);

    /**
     * Logs a new message
     * @param level on which level the message should be logged
     * @param message the message to log
     */
    void log(LogLevel level, String message);

    /**
     * Sets the minimum log level which will be reported to the server
     * @param level the log level
     */
    void setLoggerLevel(LogLevel level);

    /**
     * Gets the minimum log level which will be reported to the server
     * @return the log level
     */
    LogLevel getLoggerLevel();

}
