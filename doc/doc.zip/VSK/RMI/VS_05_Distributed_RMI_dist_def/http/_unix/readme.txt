Damit das Shell Skript http.sh ausgef�hrt wird, ben�tigt es die entsprechenden Rechte:

chmod u+x http.sh
