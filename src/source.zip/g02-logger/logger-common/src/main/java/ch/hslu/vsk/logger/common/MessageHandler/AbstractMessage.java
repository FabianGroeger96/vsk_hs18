package ch.hslu.vsk.logger.common.MessageHandler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractMessage {

    private String messageType;
    private final List<Object> argList = new ArrayList<>();
    private String endToken = ":::!_";

    public AbstractMessage(){
        this.defineMessageType();
    }

    public final void addArg(final Object arg) {
        argList.add(arg);
    }

    public final String getMessageType() {
        return messageType;
    }

    protected final void setMessageType(final String messageType) {
        this.messageType = messageType;
    }

    public final void setEndToken(final String endToken) {
        this.endToken = endToken;
    }

    public final String getEndToken() {
        return endToken;
    }

    public final Object getArg(final int index) {
        Object arg = null;
        if (index < argList.size()) {
            arg = argList.get(index);
        }
        return arg;
    }

    public final List<Object> getArgList() {
        return this.argList;
    }

    public abstract boolean readArgs(final InputStream inputStream) throws IOException;

    public abstract boolean writeArgs(final OutputStream outputStream) throws IOException;

    public abstract boolean operate();

    public abstract boolean handles(String messageType);

    public abstract AbstractMessage newCopy();

    protected abstract void defineMessageType();

}
