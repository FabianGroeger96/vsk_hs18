package ch.hslu.vsk.logger.common.Adapter;

import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.logger.common.Formatter.LogMessageFormatter;
import ch.hslu.vsk.stringpersistor.api.PersistedString;
import ch.hslu.vsk.stringpersistor.api.StringPersistor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementiert den LogPersistor mit dem Adapter Design Pattern (GoF 139).
 */
public class StringPersistorAdapter implements LogPersistor {

    private final StringPersistor stringPersistor;
    private final LogMessageFormatter formatter;

    private StringPersistorAdapter(final LogMessageFormatter formatter, final StringPersistor stringPersistor) {
        this.formatter = formatter;
        this.stringPersistor = stringPersistor;
    }

    /**
     * Erstellt eine StringPersistorAdapter Instanz
     * @param formatter den Formatter, welcher gebraucht werden soll um die Messages zu formatieren
     * @param stringPersistor den StringPersistor, welcher gebraucht wird um das Output Format zu spezifizieren
     * @return eine StringPersisterAdapter Instanz
     */
    public static StringPersistorAdapter create(final LogMessageFormatter formatter, final StringPersistor stringPersistor) {
        StringPersistorAdapter stringPersistorAdapter = new StringPersistorAdapter(formatter, stringPersistor);
        return stringPersistorAdapter;
    }

    /**
     * Speichert die LogMessage in dem festgelegten Format mit dem festgelegten StringPersistor
     * @param log die uebergebene LogMessage zum sichern
     */
    @Override
    public void save(LogMessage log) {
        this.stringPersistor.save(Instant.now(), this.formatter.format(log));
    }

    /**
     * Gibt eine Liste von PersistedLogs zurueck, welche in dem
     * festgelegten Format mit dem festgelegten StringPersistor gespeichert wurden
     * @param count die Anzahl PersistedLogs, welche ausgelesen werden sollen
     * @return eine Liste von PersistedLogs
     */
    @Override
    public List<PersistedLog> get(int count) {
        List<PersistedString> strings = this.stringPersistor.get(count);
        List<PersistedLog> result = new ArrayList<>();
        for (PersistedString string : strings){
            result.add(new PersistedLog(string.getTimestamp(), this.formatter.parse(string.getPayload())));
        }
        return result;
    }
}
