package ch.hslu.vsk.logger.common.MessageHandler;

import org.junit.Test;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class AbstractMessageTest {

    private class TestMessage extends AbstractMessage{

        private TestMessage(){
            super();
        }

        @Override
        public boolean readArgs(InputStream inputStream) {
            return false;
        }

        @Override
        public boolean writeArgs(OutputStream outputStream) {
            return false;
        }

        @Override
        public boolean operate() {
            return false;
        }

        @Override
        public boolean handles(String messageType) {
            return false;
        }

        @Override
        public AbstractMessage newCopy() {
            return null;
        }

        @Override
        protected void defineMessageType() {
            this.setMessageType("ABSTRACT");

        }
    }


    @Test
    public void testAddArgAndGetArg(){
        AbstractMessage message = new TestMessage();
        message.addArg(23);
        message.addArg("Argument");
        ArrayList<Object> args = new ArrayList<>();
        args.add(23);
        args.add("Argument");
        ArrayList<Object> messageArgs = new ArrayList<>();
        messageArgs.add(message.getArg(0));
        messageArgs.add(message.getArg(1));
        assertEquals(args, messageArgs);
    }

    @Test
    public void testGetEndToken(){
        AbstractMessage message = new TestMessage();
        String expectedEndToken = ":::!_";
        assertEquals(expectedEndToken, message.getEndToken());
    }

    @Test
    public void testSetEndToken(){
        AbstractMessage message = new TestMessage();
        String expectedEndToken = "ENDTOKEN";
        message.setEndToken(expectedEndToken);
        assertEquals(expectedEndToken, message.getEndToken());
    }

    @Test
    public void getMessageType(){
        AbstractMessage message = new TestMessage();
        String expectedMessageType = "ABSTRACT";
        assertEquals(expectedMessageType, message.getMessageType());
    }


    @Test
    public void setMessageType(){
        AbstractMessage message = new TestMessage();
        String expectedMessageType = "ABSTRACT";
        message.setMessageType(expectedMessageType);
        assertEquals(expectedMessageType, message.getMessageType());
    }



}