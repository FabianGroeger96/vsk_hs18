package ch.hslu.vsk.logger.common;

import org.junit.Before;
import org.junit.Test;

import java.time.Instant;


import static org.junit.Assert.*;

public class LogMessageTest {

    String logMessage;
    int logLevel;
    Instant date;
    int logID;
    String loggerID;

    @Before
    public void setup() {
        this.logMessage = "Test Message";
        this.logLevel = 10;
        this.date = Instant.now();
        this.logID = 1;
        this.loggerID = "test-logger";
    }

    @Test
    public void testGetMessage() {
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        assertEquals(this.logMessage, logMessage.getMessage());
    }

    @Test
    public void testGetLogID() {
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        assertEquals(this.logID, logMessage.getLogID());
    }

    @Test
    public void testGetDate() {
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        assertEquals(this.date, logMessage.getLogTime());
    }

    @Test
    public void testGetLoggerID() {
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        assertEquals(this.loggerID, logMessage.getLoggerID());
    }

    @Test
    public void testGetLogLevel(){
        LogMessage logMessage = new LogMessage(this.logMessage, this.logLevel, this.date, this.logID, this.loggerID);
        assertEquals(this.logLevel, logMessage.getLogLevel());
    }

}