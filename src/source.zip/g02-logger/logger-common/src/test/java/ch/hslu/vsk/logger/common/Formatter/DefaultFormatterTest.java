package ch.hslu.vsk.logger.common.Formatter;

import ch.hslu.vsk.logger.common.InstantFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;

import static org.junit.Assert.*;

public class DefaultFormatterTest {

    private LogMessageFormatter logMessageFormatter;

    private String logMessage;
    private int logLevel;
    private Instant testTime;
    private int logID;
    private String loggerID;

    @Before
    public void setup() {
        this.logMessageFormatter = new DefaultFormatter();

        this.logMessage = "Test Message";
        this.logLevel = 10;
        this.testTime = Instant.now();
        this.logID = 1;
        this.loggerID = "test-logger";
    }

    @Test
    public void testFormatMessage() {
        final LogMessage message = new LogMessage(this.logMessage, this.logLevel, this.testTime, this.logID, this.loggerID);

        final String expected = String.format("%s/-/%s/-/%s/-/%s/-/%s",
                InstantFormatter.getString(testTime), this.loggerID, this.logID,this.logLevel, this.logMessage);
        final String actual = this.logMessageFormatter.format(message);

        assertEquals(expected, actual);
    }

    @Test
    public void testParseMessage() {
        final LogMessage message = new LogMessage(this.logMessage, this.logLevel, this.testTime, this.logID, this.loggerID);

        final String payload = this.logMessageFormatter.format(message);

        final LogMessage parsedMessage = this.logMessageFormatter.parse(payload);

        assertEquals(this.logMessage, parsedMessage.getMessage());
        assertEquals(this.logLevel, parsedMessage.getLogLevel());
        assertEquals(this.testTime, parsedMessage.getLogTime());
        assertEquals(this.logID, parsedMessage.getLogID());
        assertEquals(this.loggerID, parsedMessage.getLoggerID());
    }

}