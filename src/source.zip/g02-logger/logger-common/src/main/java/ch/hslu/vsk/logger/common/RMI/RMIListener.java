package ch.hslu.vsk.logger.common.RMI;

import ch.hslu.vsk.logger.common.Adapter.PersistedLog;
import ch.hslu.vsk.logger.common.LogMessage;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RMIListener extends Remote {
    void push(PersistedLog message) throws RemoteException;
}
