package ch.hslu.vsk.logger.component;

import ch.hslu.vsk.logger.api.LogLevel;

import java.net.ConnectException;

public class LoggerSetup implements ch.hslu.vsk.logger.api.LoggerSetup {

    @Override
    public Logger getLogger(String loggerID, LogLevel minimumLevel, String host, int port) throws IllegalArgumentException, ConnectException {
        Logger logger = getLogger(loggerID, minimumLevel, host, port, 7);
        return logger;
    }

    public Logger getLogger(String loggerID, LogLevel minimumLevel, String host, int port, int connectionTimeout) throws IllegalArgumentException, ConnectException {
        Logger logger = new Logger(loggerID, minimumLevel, host, port, connectionTimeout);
        logger.init();
        Thread t = new Thread(logger);
        t.start();
        return logger;
    }

}
