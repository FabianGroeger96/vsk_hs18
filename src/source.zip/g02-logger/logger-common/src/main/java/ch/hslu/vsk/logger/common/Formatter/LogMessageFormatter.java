package ch.hslu.vsk.logger.common.Formatter;

import ch.hslu.vsk.logger.common.LogMessage;

/**
 * Interface fuer das Formatieren der Lognachrichten (logMessage zu String und umgekehrt).
 */
public interface LogMessageFormatter {
    /**
     * formatiert die Nachrichten vom Datentyp logMessage zu String.
     * @param logMessage die uebergeben Nachricht vom Datentyp logMessage.
     * @return die Nachricht wird als String zurueck gegeben.
     */
    public String format(LogMessage logMessage);

    /**
     * formatiert die Nachricht (zurueck) vom Datentyp String zu logMessage.
     * @param payload die uebergebene Nachricht vom Datentyp String.
     * @return die Nachricht wird als logMessage zurueck gegeben.
     */
    public LogMessage parse(String payload);
}
