package ch.hslu.vsk.logger.common.Formatter;

import ch.hslu.vsk.logger.common.InstantFormatter;
import ch.hslu.vsk.logger.common.LogMessage;

import java.time.Instant;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Spezifiziert das Default Format um LogMessages zu formatieren.
 */
public class DefaultFormatter implements LogMessageFormatter {

    /**
     * Formatiert die uebergebene LogMessage zu einem String,
     * mittels dem spezifizierten Default Format.
     * @param logMessage die uebergeben Nachricht vom Datentyp logMessage.
     * @return
     */
    @Override
    public String format(LogMessage logMessage) {
        final String payload = String.format("%s/-/%s/-/%s/-/%s/-/%s",
                InstantFormatter.getString(logMessage.getLogTime()), logMessage.getLoggerID(), logMessage.getLogID(), logMessage.getLogLevel(), logMessage.getMessage());
        return payload;
    }

    /**
     * Formatiert den uebergebenen String zu einer LogMessage,
     * mittels dem spezifizierten Default Format.
     * @param payload die uebergebene Nachricht vom Datentyp String.
     * @return
     */
    @Override
    public LogMessage parse(String payload) {
        final Pattern pattern = Pattern.compile("^(.*)\\/-/(.*)\\/-/(.*)\\/-/(.*)\\/-/(.*)$");
        final Matcher matcher = pattern.matcher(payload);

        if (!matcher.matches() || matcher.groupCount() < 5) {
            return null;
        }
        final Instant logTime = InstantFormatter.getInstant(matcher.group(1));
        final String loggerID = matcher.group(2);
        final int logID = Integer.parseInt(matcher.group(3));
        final int logLevel = Integer.parseInt(matcher.group(4));
        final String logMessage = matcher.group(5);
        final LogMessage parsedMessage = new LogMessage(logMessage, logLevel, logTime, logID, loggerID);
        return parsedMessage;
    }
}
