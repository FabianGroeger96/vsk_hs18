package ch.hslu.vsk.logger.viewer;

import ch.hslu.vsk.logger.common.Adapter.PersistedLog;
import ch.hslu.vsk.logger.common.InstantFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.logger.common.RMI.RMIListener;
import ch.hslu.vsk.logger.common.RMI.RMIServer;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 * Shows Logs from a server. Connection per RMI
 */
public final class LoggerViewer extends Application implements RMIListener {

    private final TableView<Log> table = new TableView();
    private final ObservableList<Log> data = FXCollections.observableArrayList();

    private Remote remote;

    private String registryHost = "localhost";

    public static void main(String[] args) {
        launch(args);
    }

    // Adds an entry to the tableview
    public final void add(final String quelle, final String level, final String logID,
                          final String message, final String timeErstellung, final String timeServer) {
        // 0 = add entry at the beginning
        data.add(0, new Log(quelle, level, logID, message, timeErstellung, timeServer));
    }

    @Override
    public void start(Stage stage) throws RemoteException, NotBoundException {
        final Registry reg = LocateRegistry.getRegistry(this.registryHost, Registry.REGISTRY_PORT);
        final RMIServer server = (RMIServer) reg.lookup("logServer");
        this.remote = UnicastRemoteObject.exportObject(this, 0);
        server.addListener((RMIListener) this.remote);

        Scene scene = new Scene(new Group());
        stage.setTitle("Logger Viewer");
        stage.setWidth(1100);
        stage.setHeight(700);

        final Label label = new Label("Logs");
        label.setFont(new Font("Arial", 20));

        initTable();

        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table);

        ((Group) scene.getRoot()).getChildren().addAll(vbox);

        stage.setScene(scene);
        stage.show();
    }

    private final void initTable() {
        TableColumn quelleCol = new TableColumn("Quelle");
        quelleCol.setMinWidth(100);
        quelleCol.setSortable(false);
        quelleCol.setCellValueFactory(new PropertyValueFactory<>("quelle"));

        TableColumn levelCol = new TableColumn("Level");
        levelCol.setMinWidth(80);
        levelCol.setSortable(false);
        levelCol.setCellValueFactory(new PropertyValueFactory<>("level"));

        TableColumn idCol = new TableColumn("LogID");
        idCol.setMinWidth(80);
        idCol.setSortable(false);
        idCol.setCellValueFactory(new PropertyValueFactory<>("logID"));

        TableColumn messageCol = new TableColumn("Message");
        messageCol.setMinWidth(380);
        messageCol.setSortable(false);
        messageCol.setCellValueFactory(new PropertyValueFactory<>("message"));

        TableColumn timeErstellungCol = new TableColumn("Erstellungszeit");
        timeErstellungCol.setMinWidth(210);
        timeErstellungCol.setSortable(false);
        timeErstellungCol.setCellValueFactory(new PropertyValueFactory<>("timeErstellung"));

        TableColumn timeServerCol = new TableColumn("Eingang Server");
        timeServerCol.setMinWidth(210);
        timeServerCol.setSortable(false);
        timeServerCol.setCellValueFactory(new PropertyValueFactory<>("timeServer"));

        table.setItems(data);
        table.setEditable(false);
        table.setSelectionModel(null);
        table.setMinWidth(1060);
        table.setMinHeight(600);
        table.getColumns().addAll(quelleCol, levelCol, idCol, messageCol, timeErstellungCol, timeServerCol);
    }

    @Override
    public void push(PersistedLog persistedLog) {
        LogMessage message = persistedLog.getMessage();
        String serverStamp = InstantFormatter.getString(persistedLog.getSavestamp());
        this.add(
                message.getLoggerID(),
                String.valueOf(message.getLogLevel()),
                String.valueOf(message.getLogID()),
                message.getMessage(),
                message.getLogTime().toString(),
                serverStamp);
    }
}
