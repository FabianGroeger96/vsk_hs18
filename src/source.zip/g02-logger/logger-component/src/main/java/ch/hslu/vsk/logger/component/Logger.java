package ch.hslu.vsk.logger.component;

import ch.hslu.vsk.logger.api.LogLevel;
import ch.hslu.vsk.logger.common.Adapter.LogPersistor;
import ch.hslu.vsk.logger.common.Adapter.PersistedLog;
import ch.hslu.vsk.logger.common.Adapter.StringPersistorAdapter;
import ch.hslu.vsk.logger.common.ConfigurationFileReader.ConfigurationFileReader;
import ch.hslu.vsk.logger.common.Formatter.DefaultFormatter;
import ch.hslu.vsk.logger.common.LogMessage;
import ch.hslu.vsk.logger.common.MessageHandler.LogDataMessage;
import ch.hslu.vsk.logger.common.MessageHandler.MessageHandler;
import ch.hslu.vsk.stringpersistor.impl.StringPersistorFile;

import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.time.Instant;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;

public class Logger implements ch.hslu.vsk.logger.api.Logger, Runnable {

    private String loggerID;

    private LogLevel minimumLogLevel;

    private String serverHostname;

    private int serverPort;

    private int connectionTimeout;

    private Socket socket;

    private int loggedMessages;

    private LinkedBlockingQueue<LogMessage> senderCache;

    private File cacheFile;

    private LogPersistor logPersistor;

    private boolean isCaching;

    private boolean isConnected;

    private MessageHandler messageHandler;

    private boolean allowServerless;


    Logger(final String loggerID, final LogLevel minimumLevel, final String serverHostname, final int serverPort) {
        this.isCaching = true;
        this.isConnected = false;
        this.loggerID = loggerID;
        this.minimumLogLevel = minimumLevel;
        this.serverHostname = serverHostname;
        this.serverPort = serverPort;
        this.loggedMessages = 0;
        this.connectionTimeout = 30;
        this.senderCache = new LinkedBlockingQueue<>();
        this.socket = null;
        this.allowServerless = false;
    }

    Logger(final String loggerID, final LogLevel minimumLevel, final String serverHostname, final int serverPort, final int connectionTimeout) {
        this(loggerID, minimumLevel, serverHostname, serverPort);
        this.connectionTimeout = connectionTimeout;
    }

    public void init() throws ConnectException {
        configurationFileReader();
        openSocket();
        if (!isConnected){
            if (!allowServerless){
            throw new ConnectException("Could not Initialize Logger. Connection Exception on first Connection!");
            }
            else {
                System.out.println("Starting with no Server!");
                switchToCacheMode();
            }
        }

    }

    private void configurationFileReader(){
        String configFileName = "advancedLogger.config";
        Properties prop = ConfigurationFileReader.readConfigurationFile(configFileName);
        if (prop.getProperty("TIMEOUT") != null){
            System.out.println("Found TIMEOUT Configuration in configuration file: " + configFileName);
            connectionTimeout = Integer.parseInt(prop.getProperty("TIMEOUT"));
        }
        if (prop.getProperty("ALLOW_SERVERLESS") != null){
            System.out.println("Found ALLOW_SERVERLESS Configuration in configuration file: " + configFileName);
            if (Objects.equals(prop.getProperty("ALLOW_SERVERLESS").toUpperCase(), "TRUE")){
                allowServerless = true;
            }
        }
    }

    private void switchToOnlineMode(){
        System.out.println("Switching to Online Mode!");
        if (this.logPersistor != null){
            for (PersistedLog persistedLog : this.logPersistor.get(Integer.MAX_VALUE)){
                senderCache.add(persistedLog.getMessage());
            }
        }
        this.isCaching = false;
    }

    private void switchToCacheMode() {
        System.out.println("Switching to Cache Mode!");
        createCacheFile();
        for (LogMessage log : senderCache){
            logPersistor.save(log);
        }
        senderCache.clear();
    }

    private void createCacheFile() {
        try {
            this.cacheFile = File.createTempFile("cache", ".log") ;
        } catch (IOException e) {
            System.out.println("Can not use Temp Cache File! Only Caching to Memory");
        }
        StringPersistorFile stringPersistor = new StringPersistorFile();
        stringPersistor.setFile(this.cacheFile);
        System.out.println("Created Cache File in Path: " + cacheFile.getAbsolutePath());
        this.logPersistor = StringPersistorAdapter.create(new DefaultFormatter(), stringPersistor);
    }

    private void openSocket() {
        try {
            if (this.socket == null){
                this.socket = new Socket(this.serverHostname, this.serverPort);
                System.out.println("Successfully connected to logger server " + this.serverHostname + ":"
                        + this.serverPort);
            }
            this.messageHandler = new MessageHandler(socket.getInputStream(), socket.getOutputStream());
            this.isConnected = true;
            switchToOnlineMode();
        }
        catch (IOException e) {
            this.isConnected = false;
        }
    }

    private void sendMessageFromCache() throws IOException {
        if (!senderCache.isEmpty()){
            LogMessage logMessage = senderCache.peek();
            LogDataMessage message = new LogDataMessage(logMessage);
            this.messageHandler.sendMessage(message);
            senderCache.poll();
        }
    }

    @Override
    public void log(LogLevel logLevel, String message) {
            if (logLevel.getPriority() >= this.minimumLogLevel.getPriority()) {
                LogMessage logMessage = new LogMessage(message, logLevel.getPriority(), Instant.now(), loggedMessages, this.loggerID);
                if (isCaching){
                    this.logPersistor.save(logMessage);
                }
                else {
                    this.senderCache.add(logMessage);
                }
                this.loggedMessages++;
            }
    }

    @Override
    public void setMinimumLogLevel(LogLevel minimumLevel) {
        this.minimumLogLevel = minimumLevel;
    }

    @Override
    public String getID() {
        return this.loggerID;
    }

    @Override
    public void trace(String message){
        log(LogLevel.TRACE, message);
    }

    @Override
    public void debug(String message){
        log(LogLevel.DEBUG, message);
    }

    @Override
    public void info(String message){
        log(LogLevel.INFO, message);
    }

    @Override
    public void warning(String message){
        log(LogLevel.WARNING, message);
    }

    @Override
    public void error(String message){
        log(LogLevel.ERROR, message);
    }

    @Override
    public void critical(String message){
        log(LogLevel.CRITICAL, message);
    }

    private void disconnect(){
        if (socket !=null) {
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Could not Close Socket!");
                System.out.println("Deleting Socket!");
            } finally {
                isCaching = true;
                isConnected = false;
                socket = null;
            }
        }
    }

    @Override
    public void run() {
        while (true){
            while(messageHandler != null && isConnected){
                isCaching = false;
                try {
                    sendMessageFromCache();
                } catch (UTFDataFormatException e){
                    //
                }
                catch (IOException e) {
                    disconnect();
                    switchToCacheMode();
                    break;
                }
            }
            System.out.println("Timeing out....");
            try {
                Thread.sleep(connectionTimeout * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Try to reconnect");
            openSocket();
        }
    }
}
