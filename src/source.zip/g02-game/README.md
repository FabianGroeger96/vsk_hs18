# GameOfLife

Applikation fuer die Integration des Loggers der Gruppe g02 im VSK-18FS.

### Buildstatus
* [![Build Status](https://jenkins-vsk.el.eee.intern/jenkins/buildStatus/icon?job=g02-game)](https://jenkins-vsk.el.eee.intern/jenkins/job/g02-game/)

> Hinweis: Buildstatus nur innerhalb HSLU-Netz (oder per VPN) sichtbar!